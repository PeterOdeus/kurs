package controller;

import java.util.List;

public interface SearchResultHandler {
	public void handleSearchResults(List<String> resultStrings);
}
