package swing.övning22;

import java.util.List;

public interface SearchResultHandler {
	public void handleSearchResults(List<String> resultStrings);
}
